import streamlit as st
from streamlit_login_auth_ui.widgets import __login__
from streamlit_option_menu import option_menu
from Encryption import encrypt_file_ui 
from Decryption import decrypt_file_ui


__login__obj = __login__(auth_token = "courier_auth_token",
                    company_name = "Shims",
                    width = 200, height = 250,
                    logout_button_name = 'Logout', hide_menu_bool = False,
                    hide_footer_bool = False,
                    lottie_url = 'https://assets2.lottiefiles.com/packages/lf20_jcikwtux.json')

LOGGED_IN= __login__obj.build_login_ui()
username= __login__obj.get_username()

def local_css(file_name):
    with open(file_name, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def get_file_icon(file_name):
    if file_name.endswith('.pdf'):
        return "https://img.icons8.com/color/48/000000/pdf-2.png"
    elif file_name.endswith(('.jpg', '.png', '.gif')):
        return "https://img.icons8.com/color/48/000000/image-file.png"
    else:
        return "https://img.icons8.com/color/48/000000/document--v1.png"

def show_file_preview():
    st.markdown("<h1 style='text-align: center; color: #ffffff;'>Encrypted Files Preview</h1>", unsafe_allow_html=True)

    sample_files = [
        {"name": "document1.pdf", "description": "Important contract", "ipfs_link": "ipfs://abc123", "key": "****"},
        {"name": "image1.jpg", "description": "Family photo", "ipfs_link": "ipfs://def456", "key": "****"},
        {"name": "report.docx", "description": "Annual financial report", "ipfs_link": "ipfs://ghi789", "key": "****"},
        {"name": "presentation.pptx", "description": "Project presentation", "ipfs_link": "ipfs://jkl012", "key": "****"},
        {"name": "thesis.pdf", "description": "Research thesis", "ipfs_link": "ipfs://mno345", "key": "****"},
        {"name": "holiday.jpg", "description": "Vacation snapshot", "ipfs_link": "ipfs://pqr678", "key": "****"},
        {"name": "meeting_notes.docx", "description": "Meeting notes", "ipfs_link": "ipfs://stu901", "key": "****"},
        {"name": "budget.xlsx", "description": "Monthly budget", "ipfs_link": "ipfs://vwx234", "key": "****"},
        {"name": "design.psd", "description": "Photoshop design", "ipfs_link": "ipfs://yz1234", "key": "****"},
    ]

    cols_per_row = 3  # Adjust the number of columns per row
    rows = [sample_files[i:i + cols_per_row] for i in range(0, len(sample_files), cols_per_row)]

    for row in rows:
        cols = st.columns(len(row))
        for col, file in zip(cols, row):
            with col:
                st.markdown(
                    f"""
                    <div class="file-card">
                        <img src="{get_file_icon(file['name'])}" alt="File Icon" class="file-icon"/>
                        <h3 class="file-name">{file['name']}</h3>
                        <p class="file-desc">{file['description']}</p>
                        <p><strong>🔗 IPFS Link:</strong> <a href="{file['ipfs_link']}">{file['ipfs_link']}</a></p>
                        <p><strong>🔑 Key:</strong> {file['key']}</p>
                        <div class="button-group">
                            <button class="edit-btn"><img src="https://img.icons8.com/ios-glyphs/30/ffffff/edit.png" class="icon"> Edit</button>
                            <button class="delete-btn"><img src="https://img.icons8.com/ios-glyphs/30/ffffff/trash.png" class="icon"> Delete</button>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
        st.markdown("---")  # Only one Markdown line after each row



if LOGGED_IN == True:
    local_css("style.css")  # Load custom CSS

    # Sidebar
    with st.sidebar:
        selected = option_menu(
            menu_title="File Operations",
            options=["Home", "Encryption", "Decryption"],
            icons=["", "lock", "unlock"],
            menu_icon="cast",
            default_index=0,  # Start with "Select an Operation" as default
        )

    # Main content
    if selected == "Encryption":
        encrypt_file_ui()  # Call the encryption UI from encryption.py
    elif selected == "Decryption":
        decrypt_file_ui()
    elif selected == "Home":
        show_file_preview()  # Show file preview when no operation is selected
    else:
        show_file_preview()  # Show file preview if an unexpected option is selected
                                      
